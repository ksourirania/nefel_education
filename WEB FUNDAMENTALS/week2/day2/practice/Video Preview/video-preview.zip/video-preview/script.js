console.log("page loaded...");
function playvideo(vid){
    console.log(vid);
    Vid.play();
}
fuction pausevideo(vid){
    console.log(vid):
    Vid.play();
}