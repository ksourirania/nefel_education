function loding(){
    alert("loding weather report...")
}
var cookie=document.querySelector(".cookies")
function accept(){
    cookie.remove();
}
fuction change(e){
    console.log(e.value);
}
